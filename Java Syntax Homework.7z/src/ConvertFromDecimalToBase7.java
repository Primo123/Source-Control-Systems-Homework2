import java.util.Scanner;

/**
 * Created by Stark on 3/23/2016.
 */
public class ConvertFromDecimalToBase7 {
    public static void main(String[] args) {
        System.out.println("Enter the number you want to convert to 7 base: ");
        Scanner scanner = new Scanner(System.in);
        Integer numberToConvert = scanner.nextInt();
        System.out.print(Integer.toString(numberToConvert, 7));
    }
}

