import java.util.Scanner;

/**
 * Created by Stark on 3/23/2016.
 */
public class RectangleArea {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int a = input.nextInt();
    int b = input.nextInt();
    int rectangleArea = a * b;

    System.out.println(rectangleArea);

}
}
